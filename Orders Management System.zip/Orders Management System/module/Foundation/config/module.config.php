<?php

return [
    'view_manager' => [
        'template_map' => [
            'crud/pagination' => __DIR__ . '/../view/crud/pagination.phtml',
            'crud/form' => __DIR__ . '/../view/crud/form.phtml',
            'crud/delete-confirm-modal' => __DIR__ . '/../view/crud/delete-confirm-modal.phtml',
        ]
    ]
];
