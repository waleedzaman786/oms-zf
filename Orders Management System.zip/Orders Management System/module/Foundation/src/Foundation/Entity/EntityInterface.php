<?php

namespace Foundation\Entity;


interface EntityInterface
{
    /**
     * @return int
     */
    public function getId();
}
