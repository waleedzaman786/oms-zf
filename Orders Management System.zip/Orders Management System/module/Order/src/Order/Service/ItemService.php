<?php

namespace Order\Service;

use Foundation\Crud\AbstractCrudService as CrudService;

class ItemService extends CrudService
{
}
