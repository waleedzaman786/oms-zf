<?php

namespace Order\Service;

use Foundation\Crud\AbstractCrudService as CrudService;

class CustomerService extends CrudService
{

}
