<?php

namespace Order\Entity\Repository;

use Foundation\Crud\AbstractCrudRepository as CrudRepository;

class ItemRepository extends CrudRepository
{

}
