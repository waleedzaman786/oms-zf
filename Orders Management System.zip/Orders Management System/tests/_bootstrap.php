<?php
// This is global bootstrap for autoloading

Codeception\Util\Autoload::registerSuffix('Trait', __DIR__.'/Traits');
