;(function() {
  'use strict';

  angular.module('zf2orders')
    .controller('MainController', function ($scope) {
    
  });
})();