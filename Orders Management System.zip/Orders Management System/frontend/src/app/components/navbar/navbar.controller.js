;(function() {
	'use strict';

	angular.module('zf2orders')
		.controller('NavbarController', function ($scope) {
	});
})();